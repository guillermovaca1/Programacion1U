typedef struct {
    char nombre[50];
    int cantidad;
    float precio;
} Producto;